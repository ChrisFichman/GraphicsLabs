README.txt

Make instructions:
type "make" to compile the graph_lorenz.c and make lorenz.exe

Running lorenz.exe:
./lorenz 

Special Functionality:
'x', 'y', and 'z' keys: set the mode for translation of the axis.
'+' and '-' keys: 	translate the axis and attractor in the 
					positive or negative direction.

Arrow Keys:	Rotate the image

'1'-'4' Keys: Choose between preset values of r, b, and s.
'5' Key: User input mode(press each time you disire to input values)
'0' Key: Reset

'w': enter w modification mode(use + and - to change the value of w)

